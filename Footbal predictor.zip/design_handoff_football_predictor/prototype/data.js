/* ──────────────────────────────────────────────────────────────
   Football Predictor — demo data (WC 2026)
   Sets window.APPDATA. Plain JS so it runs before the Babel app.
   ────────────────────────────────────────────────────────────── */
(function () {
  // — Teams: name (SLO) · flag · jersey accent —
  const T = (name, flag, color) => ({ name, flag, color });
  const teams = {
    MEX: T('Mehika', '🇲🇽', '#006847'), CRO: T('Hrvaška', '🇭🇷', '#c8102e'),
    ECU: T('Ekvador', '🇪🇨', '#ffce00'), KSA: T('Saudova Arabija', '🇸🇦', '#006c35'),
    CAN: T('Kanada', '🇨🇦', '#d52b1e'), BEL: T('Belgija', '🇧🇪', '#c8102e'),
    MAR: T('Maroko', '🇲🇦', '#c1272d'), KOR: T('Južna Koreja', '🇰🇷', '#0047a0'),
    USA: T('ZDA', '🇺🇸', '#0a3161'), URU: T('Urugvaj', '🇺🇾', '#7bafd4'),
    JPN: T('Japonska', '🇯🇵', '#bc002d'), GHA: T('Gana', '🇬🇭', '#006b3f'),
    ARG: T('Argentina', '🇦🇷', '#6cace4'), AUS: T('Avstralija', '🇦🇺', '#00843d'),
    POL: T('Poljska', '🇵🇱', '#dc143c'), SEN: T('Senegal', '🇸🇳', '#00853f'),
    FRA: T('Francija', '🇫🇷', '#1e3a8a'), SUI: T('Švica', '🇨🇭', '#d52b1e'),
    NGA: T('Nigerija', '🇳🇬', '#008751'), QAT: T('Katar', '🇶🇦', '#8a1538'),
    BRA: T('Brazilija', '🇧🇷', '#ffdf00'), DEN: T('Danska', '🇩🇰', '#c8102e'),
    CMR: T('Kamerun', '🇨🇲', '#007a5e'), CRC: T('Kostarika', '🇨🇷', '#002b7f'),
    ENG: T('Anglija', '🇬🇧', '#cf142b'), NED: T('Nizozemska', '🇳🇱', '#ff6c00'),
    IRN: T('Iran', '🇮🇷', '#239f40'), PAN: T('Panama', '🇵🇦', '#005293'),
    ESP: T('Španija', '🇪🇸', '#c60b1e'), GER: T('Nemčija', '🇩🇪', '#111111'),
    TUN: T('Tunizija', '🇹🇳', '#e70013'), PER: T('Peru', '🇵🇪', '#d91023'),
    POR: T('Portugalska', '🇵🇹', '#006600'), COL: T('Kolumbija', '🇨🇴', '#fcd116'),
    SRB: T('Srbija', '🇷🇸', '#c6363c'), EGY: T('Egipt', '🇪🇬', '#ce1126'),
    ITA: T('Italija', '🇮🇹', '#0066b3'), ALG: T('Alžirija', '🇩🇿', '#006633'),
    CHI: T('Čile', '🇨🇱', '#0039a6'), SWE: T('Švedska', '🇸🇪', '#005293'),
    UKR: T('Ukrajina', '🇺🇦', '#0057b7'), CIV: T('Slonokoščena obala', '🇨🇮', '#f77f00'),
    NZL: T('Nova Zelandija', '🇳🇿', '#1b1b1b'), SVN: T('Slovenija', '🇸🇮', '#005da4'),
    NOR: T('Norveška', '🇳🇴', '#ba0c2f'), MLI: T('Mali', '🇲🇱', '#14b53a'),
    PAR: T('Paragvaj', '🇵🇾', '#d52b1e'), HON: T('Honduras', '🇭🇳', '#0073cf'),
  };

  // — 12 groups × 4 teams —
  const groupTeams = {
    A: ['MEX', 'CRO', 'ECU', 'KSA'], B: ['CAN', 'BEL', 'MAR', 'KOR'],
    C: ['USA', 'URU', 'JPN', 'GHA'], D: ['ARG', 'AUS', 'POL', 'SEN'],
    E: ['FRA', 'SUI', 'NGA', 'QAT'], F: ['BRA', 'DEN', 'CMR', 'CRC'],
    G: ['ENG', 'NED', 'IRN', 'PAN'], H: ['ESP', 'GER', 'TUN', 'PER'],
    I: ['POR', 'COL', 'SRB', 'EGY'], J: ['ITA', 'ALG', 'CHI', 'SWE'],
    K: ['UKR', 'CIV', 'NZL', 'SVN'], L: ['NOR', 'MLI', 'PAR', 'HON'],
  };

  // — Slovenian date formatter → "ned., 11. 06. ob 21:00" —
  const dayAbbr = ['ned.', 'pon.', 'tor.', 'sre.', 'čet.', 'pet.', 'sob.'];
  const pad = (n) => String(n).padStart(2, '0');
  function fmt(d) {
    return `${dayAbbr[d.getDay()]}, ${pad(d.getDate())}. ${pad(d.getMonth() + 1)}. ob ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  // — Scoring engine (per spec §5) —
  function score(pred, actual, isKnockout) {
    if (!pred || !actual) return null;
    const pd = pred.home - pred.away, ad = actual.home - actual.away;
    let pts;
    if (pred.home === actual.home && pred.away === actual.away) pts = 3;       // točen rezultat
    else if (pd === ad) pts = 2;                                               // pravilna razlika / remi
    else if (Math.sign(pd) === Math.sign(ad)) pts = 1;                         // pravilen zmagovalec
    else pts = 0;                                                              // napačno
    if (isKnockout && pd === 0 && ad === 0 && pred.advancing && pred.advancing === actual.advancing) pts += 1;
    return pts;
  }

  // Finished-match templates → varied point outcomes (3, 2, 1)
  const finishedTpl = [
    { actual: { home: 2, away: 1 }, pred: { home: 2, away: 1 } }, // exact → 3
    { actual: { home: 0, away: 0 }, pred: { home: 1, away: 1 } }, // correct draw → 2
    { actual: { home: 3, away: 1 }, pred: { home: 1, away: 0 } }, // winner only → 1
  ];

  let mid = 0;
  function genGroup(gid) {
    const codes = groupTeams[gid];
    const tm = (i) => ({ ...teams[codes[i]], code: codes[i] });
    const pairs = [[0, 1], [2, 3], [0, 2], [1, 3], [3, 0], [1, 2]];
    // base date staggered per group (June 2026)
    const base = new Date(2026, 5, 11 + (gid.charCodeAt(0) - 65)); // June = month 5
    const slots = [
      [0, 18], [0, 21], [4, 18], [4, 21], [8, 18], [8, 21], // [dayOffset, hour]
    ];
    return pairs.map((p, i) => {
      const d = new Date(base); d.setDate(d.getDate() + slots[i][0]); d.setHours(slots[i][1], 0, 0, 0);
      const home = tm(p[0]), away = tm(p[1]);
      const id = `${gid}${i}-${mid++}`;
      let status, actual = null, myPred = null, earned = null;
      if (i < 3) { // finished
        status = 'finished';
        const tpl = finishedTpl[i];
        actual = tpl.actual; myPred = tpl.pred;
        earned = score(myPred, actual, false);
      } else if (i === 3) { // locked
        status = 'locked';
        myPred = { home: 1, away: 2 };
      } else if (i === 4) { // open, has saved pred
        status = 'open';
        myPred = { home: 2, away: 0 };
      } else { // open, no pred yet
        status = 'open';
      }
      return { id, group: gid, stage: `Skupina ${gid}`, isKnockout: false, when: fmt(d), kickoff: +d, home, away, status, actual, myPred, earned };
    });
  }

  const groupMatches = {};
  Object.keys(groupTeams).forEach((g) => { groupMatches[g] = genGroup(g); });

  // — Knockout sample fixtures (open, demonstrate remi → advancing) —
  const ko = (id, stageLabel, c1, c2, day, hour) => {
    const d = new Date(2026, 5, day, hour, 0, 0, 0);
    return {
      id, group: stageLabel, stage: stageLabel, isKnockout: true,
      when: fmt(d), kickoff: +d,
      home: { ...teams[c1], code: c1 }, away: { ...teams[c2], code: c2 },
      status: 'open', actual: null, myPred: null, earned: null,
    };
  };
  const knockout = {
    'Krog 32': [
      ko('k32-1', 'Krog 32', 'ARG', 'KOR', 28, 18), ko('k32-2', 'Krog 32', 'FRA', 'GHA', 28, 21),
      ko('k32-3', 'Krog 32', 'BRA', 'KSA', 29, 18), ko('k32-4', 'Krog 32', 'ESP', 'IRN', 29, 21),
    ],
    'Osmina finala': [
      ko('o8-1', 'Osmina finala', 'ARG', 'FRA', 2, 18), ko('o8-2', 'Osmina finala', 'BRA', 'ENG', 2, 21),
      ko('o8-3', 'Osmina finala', 'POR', 'NED', 3, 18), ko('o8-4', 'Osmina finala', 'GER', 'CRO', 3, 21),
    ],
    'Četrtfinale': [
      ko('q4-1', 'Četrtfinale', 'ARG', 'BRA', 5, 18), ko('q4-2', 'Četrtfinale', 'FRA', 'ENG', 5, 21),
    ],
    'Polfinale': [
      ko('s2-1', 'Polfinale', 'ARG', 'FRA', 8, 21), ko('s2-2', 'Polfinale', 'BRA', 'ESP', 9, 21),
    ],
    'Finale': [
      ko('f-1', 'Finale', 'ARG', 'BRA', 12, 21),
    ],
  };

  // — Current user + leaderboards —
  const me = { id: 'u-franci', name: 'Franci Bačar', email: 'franci@goodish.agency', initials: 'FB', emoji: '😀', isAdmin: true, optIn: true };

  const player = (name, emoji, exact, points, you = false) => ({ name, emoji, exact, points, you, initials: name.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase() });
  const globalBoard = [
    player('Matevž Šauperl', '😎', 4, 16),
    player('Ana Novak', '🦊', 4, 14),
    player('Franci Bačar', '😀', 3, 12, true),
    player('Marko Kovač', '🐻', 2, 11),
    player('Petra Krajnc', '🌸', 2, 9),
    player('Luka Zupan', '⚡', 1, 8),
    player('Nina Horvat', '🐝', 1, 6),
    player('Žan Vidmar', '🎯', 0, 4),
  ].sort((a, b) => b.points - a.points || b.exact - a.exact);

  const teamBoard = [
    player('Matevž Šauperl', '😎', 4, 16),
    player('Franci Bačar', '😀', 3, 12, true),
    player('Marko Kovač', '🐻', 2, 11),
    player('Petra Krajnc', '🌸', 2, 9),
    player('Ana Novak', '🦊', 1, 7),
  ].sort((a, b) => b.points - a.points || b.exact - a.exact);

  // — Groups (private) —
  const myGroups = [
    {
      id: 'g1', name: 'Goodish ekipa', role: 'Admin', code: 'ab3c8f2e',
      members: [
        { name: 'Franci Bačar', emoji: '😀', you: true, admin: false },
        { name: 'Matevž Šauperl', emoji: '😎', admin: true },
        { name: 'Ana Novak', emoji: '🦊' },
        { name: 'Marko Kovač', emoji: '🐻' },
        { name: 'Petra Krajnc', emoji: '🌸' },
      ],
    },
    {
      id: 'g2', name: 'Futsal petki', role: 'Član', code: '7d2e9a1b',
      members: [
        { name: 'Luka Zupan', emoji: '⚡', admin: true },
        { name: 'Franci Bačar', emoji: '😀', you: true },
        { name: 'Nina Horvat', emoji: '🐝' },
        { name: 'Žan Vidmar', emoji: '🎯' },
      ],
    },
  ];

  const groupOrder = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'];
  const knockoutOrder = ['Krog 32', 'Osmina finala', 'Četrtfinale', 'Polfinale', 'Finale'];

  window.APPDATA = {
    teams, groupTeams, groupMatches, knockout, me,
    globalBoard, teamBoard, myGroups, groupOrder, knockoutOrder, score,
  };
})();
