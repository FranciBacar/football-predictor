/* ──────────────────────────────────────────────────────────────
   Football Predictor — App root
   ────────────────────────────────────────────────────────────── */
function App() {
  const D = window.APPDATA;
  const [screen, setScreen] = React.useState('login'); // 'login' | 'app'
  const [tab, setTab] = React.useState('napovedi');
  const [admin, setAdmin] = React.useState(false);
  const [optIn, setOptIn] = React.useState(D.me.optIn);
  const [toastMsg, setToastMsg] = React.useState(null);
  const scrollRef = React.useRef(null);
  const toastTimer = React.useRef(null);

  // init predictions from data
  const [preds, setPreds] = React.useState(() => {
    const p = {};
    const all = [...Object.values(D.groupMatches).flat(), ...Object.values(D.knockout).flat()];
    all.forEach((m) => { p[m.id] = m.myPred ? { ...m.myPred } : { home: 0, away: 0 }; });
    return p;
  });
  const [saved, setSaved] = React.useState(() => {
    const s = {};
    const all = [...Object.values(D.groupMatches).flat(), ...Object.values(D.knockout).flat()];
    all.forEach((m) => { s[m.id] = m.myPred ? { ...m.myPred } : null; });
    return s;
  });

  const toast = (msg) => {
    setToastMsg(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(null), 2200);
  };

  const onChange = (id, p) => setPreds((prev) => ({ ...prev, [id]: p }));
  const onSave = (id) => {
    setSaved((prev) => ({ ...prev, [id]: { ...preds[id] } }));
    toast({ icon: '✓', text: 'Napoved shranjena' });
  };

  // scroll to top on view change
  React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [tab, admin, screen]);

  if (screen === 'login') {
    return (
      <div className="stage">
        <IOSDevice>
          <Login onLogin={() => { setScreen('app'); setTab('napovedi'); }} />
        </IOSDevice>
      </div>
    );
  }

  let view;
  if (admin) view = <Admin onBack={() => setAdmin(false)} toast={toast} />;
  else if (tab === 'napovedi') view = <Dashboard preds={preds} saved={saved} onChange={onChange} onSave={onSave} />;
  else if (tab === 'lestvica') view = <Leaderboard />;
  else if (tab === 'skupine') view = <Groups toast={toast} />;
  else view = <Profile optIn={optIn} setOptIn={setOptIn} onLogout={() => { setScreen('login'); setAdmin(false); }} onAdmin={() => setAdmin(true)} toast={toast} />;

  return (
    <div className="stage">
      <IOSDevice>
        <div className="app">
          <div className="statusclear" />
          <div className="scroll" ref={scrollRef}>
            <div className="app-screen" key={admin ? 'admin' : tab}>
              {view}
            </div>
          </div>
          {!admin && <BottomNav tab={tab} setTab={setTab} />}
          <Toast msg={toastMsg} />
        </div>
      </IOSDevice>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
