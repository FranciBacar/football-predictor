/* ──────────────────────────────────────────────────────────────
   Football Predictor — Admin panel
   ────────────────────────────────────────────────────────────── */
function Admin({ onBack, toast }) {
  const D = window.APPDATA;
  const [open, setOpen] = React.useState(null);
  const [scores, setScores] = React.useState({});
  const [synced, setSynced] = React.useState({ updated: 6, skipped: 2, errors: 0, ran: false });
  const list = D.groupMatches['A'].concat(D.knockout['Krog 32'].slice(0, 2));

  const setScore = (id, side, v) => setScores((s) => ({ ...s, [id]: { home: 0, away: 0, ...s[id], [side]: Math.max(0, v) } }));

  return (
    <div className="screen">
      <div className="greet" style={{ paddingTop: 0, alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="copybtn" style={{ height: 38, width: 38, justifyContent: 'center', padding: 0 }} onClick={onBack}>
            <svg width="9" height="15" viewBox="0 0 9 15"><path d="M8 1L2 7.5 8 14" stroke="#0f766e" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
          <div>
            <h1 style={{ fontSize: 23 }}>Admin panel</h1>
            <p>Upravljanje tekem in rezultatov</p>
          </div>
        </div>
        <span className="adminchip">🛠️ Admin</span>
      </div>

      <div className="infocard">
        <div className="it"><span>🔗</span>Vir podatkov</div>
        <div className="id">Rezultati se samodejno berejo iz <a href="https://github.com/openfootball" target="_blank" rel="noreferrer">openfootball</a> GitHub repozitorija. Cron sync teče vsakih 30 min (Vercel).</div>
      </div>

      <div className="infocard">
        <div className="it"><span>🔄</span>Sync rezultatov</div>
        <button className="btn btn-grad" style={{ marginTop: 4 }} onClick={() => { setSynced({ updated: 4, skipped: 3, errors: 0, ran: true }); toast({ icon: '🔄', text: 'Sync končan — 4 posodobljene' }); }}>
          Ročni sync zdaj
        </button>
        <div className="syncstat">
          <div className="s"><div className="n" style={{ color: 'var(--green)' }}>{synced.updated}</div><div className="k">Posodobljeno</div></div>
          <div className="s"><div className="n" style={{ color: '#475467' }}>{synced.skipped}</div><div className="k">Preskočeno</div></div>
          <div className="s"><div className="n" style={{ color: synced.errors ? 'var(--red)' : '#475467' }}>{synced.errors}</div><div className="k">Napake</div></div>
        </div>
      </div>

      <div className="seclabel" style={{ padding: '6px 22px 8px' }}>Ročni vnos rezultatov</div>
      {list.map((m) => {
        const isOpen = open === m.id;
        const sc = scores[m.id] || { home: m.actual ? m.actual.home : 0, away: m.actual ? m.actual.away : 0 };
        const st = m.status === 'finished' ? 'Končano' : m.status === 'locked' ? 'Zaklenjeno' : 'Odprto';
        const stc = m.status === 'finished' ? 'sb-finished' : m.status === 'locked' ? 'sb-locked' : 'sb-open';
        return (
          <div key={m.id} className="bigcard" style={{ margin: '0 16px 10px' }}>
            <div style={{ padding: '13px 16px', display: 'flex', alignItems: 'center', gap: 11, cursor: 'pointer' }} onClick={() => setOpen(isOpen ? null : m.id)}>
              <div style={{ fontSize: 19 }}>{m.home.flag}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 650 }}>{m.home.name} – {m.away.name}</div>
                <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>{m.when}</div>
              </div>
              <div style={{ fontSize: 19 }}>{m.away.flag}</div>
              <span className={'statusbadge ' + stc}><span className="led" />{st}</span>
            </div>
            {isOpen && (
              <div style={{ padding: '4px 16px 16px', borderTop: '1px solid var(--line)' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, margin: '14px 0' }}>
                  <Stepper value={sc.home} editable onChange={(v) => setScore(m.id, 'home', v)} />
                  <span className="colon">:</span>
                  <Stepper value={sc.away} editable onChange={(v) => setScore(m.id, 'away', v)} />
                </div>
                <div style={{ display: 'flex', gap: 9 }}>
                  <button className="btn btn-ghost" onClick={() => setOpen(null)}>Prekliči</button>
                  <button className="btn btn-grad" onClick={() => { setOpen(null); toast({ icon: '✅', text: 'Rezultat shranjen' }); }}>Shrani rezultat</button>
                </div>
              </div>
            )}
          </div>
        );
      })}

      <AppFooter />
    </div>
  );
}

Object.assign(window, { Admin });
