/* ──────────────────────────────────────────────────────────────
   Football Predictor — main screens
   ────────────────────────────────────────────────────────────── */

// ── DASHBOARD / NAPOVEDI ──────────────────────────────────────
function Dashboard({ preds, saved, onChange, onSave }) {
  const D = window.APPDATA;
  const [sel, setSel] = React.useState('A');
  const tabs = [
    ...D.groupOrder.map((g) => ({ key: g, label: `Skupina ${g}` })),
    ...D.knockoutOrder.map((k) => ({ key: k, label: k })),
  ];
  const matches = D.groupMatches[sel] || D.knockout[sel] || [];

  return (
    <div className="screen">
      <div className="greet">
        <div>
          <h1>Pozdravljen, Franci! ⚽</h1>
          <p>Vnesi napovedi za prihajajoče tekme. Zaklene se 15 min pred začetkom.</p>
        </div>
        <div className="av">{D.me.emoji}</div>
      </div>

      <div className="pillrow scrollx">
        {tabs.map((t) => (
          <button key={t.key} className={'pill' + (sel === t.key ? ' on' : '')} onClick={() => setSel(t.key)}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ paddingTop: 2 }}>
        {matches.map((m) => (
          <MatchCard key={m.id} match={m}
            pred={preds[m.id]} saved={saved[m.id]}
            onChange={(p) => onChange(m.id, p)} onSave={() => onSave(m.id)} />
        ))}
      </div>

      <div style={{ padding: '0 0 4px' }}><AppFooter /></div>
    </div>
  );
}

// ── LESTVICA ──────────────────────────────────────────────────
function Leaderboard() {
  const D = window.APPDATA;
  const boards = {
    'Globalna': D.globalBoard,
    'Goodish ekipa': D.teamBoard,
    'Futsal petki': [
      { name: 'Luka Zupan', emoji: '⚡', exact: 2, points: 10 },
      { name: 'Franci Bačar', emoji: '😀', exact: 3, points: 12, you: true },
      { name: 'Nina Horvat', emoji: '🐝', exact: 1, points: 6 },
      { name: 'Žan Vidmar', emoji: '🎯', exact: 0, points: 4 },
    ].sort((a, b) => b.points - a.points || b.exact - a.exact),
  };
  const tabKeys = ['Globalna', ...D.myGroups.map((g) => g.name)];
  const [tab, setTab] = React.useState('Globalna');
  const rows = boards[tab] || D.globalBoard;
  const medals = ['🥇', '🥈', '🥉'];

  return (
    <div className="screen">
      <div className="page-title">
        <h1>Lestvica</h1>
        <p>Razvrstitev po točkah. Pri izenačenju šteje več točnih rezultatov.</p>
      </div>

      <div className="pillrow scrollx">
        {tabKeys.map((k) => (
          <button key={k} className={'pill' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}>{k}</button>
        ))}
      </div>

      <div className="lbcard">
        <div className="lbhead">
          <div className="r">#</div><div>Igralec</div><div className="r">Točni</div><div className="r">Točke</div>
        </div>
        {rows.map((p, i) => (
          <div key={p.name} className={'lbrow' + (p.you ? ' you' : '')}>
            <div className={'lbrank' + (i < 3 ? ' medal' : '')}>{i < 3 ? medals[i] : i + 1}</div>
            <div className="lbplayer">
              {p.emoji
                ? <div className="lbav">{p.emoji}</div>
                : <div className="lbav initials">{p.initials}</div>}
              <div className="lbname">{p.name}{p.you && <span className="me"> (ti)</span>}</div>
            </div>
            <div className="lbexact">{p.exact}</div>
            <div className="lbpts">{p.points}</div>
          </div>
        ))}
      </div>

      <div className="scorebox-info">
        <h3>Sistem točkovanja</h3>
        <div className="scrow"><div className="l"><span className="ic">🎯</span>Točen rezultat</div><div className="p">3 točke</div></div>
        <div className="scrow"><div className="l"><span className="ic">📐</span>Pravilna razlika / remi</div><div className="p">2 točki</div></div>
        <div className="scrow"><div className="l"><span className="ic">✅</span>Pravilen zmagovalec</div><div className="p">1 točka</div></div>
        <div className="scrow"><div className="l"><span className="ic">⚡</span>Bonus (izločilni)</div><div className="p">+1 točka</div></div>
      </div>

      <AppFooter />
    </div>
  );
}

// ── SKUPINE ───────────────────────────────────────────────────
function Groups({ toast }) {
  const D = window.APPDATA;
  const [newName, setNewName] = React.useState('');
  const [joinCode, setJoinCode] = React.useState('');
  const [expanded, setExpanded] = React.useState({ g1: false, g2: false });
  const [copied, setCopied] = React.useState(null);

  const copy = (g) => {
    const url = `https://app.goodish.agency/join?code=${g.code}`;
    if (navigator.clipboard) navigator.clipboard.writeText(url).catch(() => {});
    setCopied(g.id);
    toast({ icon: '📋', text: 'Povabilo kopirano' });
    setTimeout(() => setCopied(null), 1600);
  };

  return (
    <div className="screen">
      <div className="page-title">
        <h1>Moje skupine</h1>
        <p>Tekmuj s prijatelji v zasebnih skupinah.</p>
      </div>

      <div className="gridtwo">
        <div className="actioncard">
          <div className="ttl"><span>➕</span>Ustvari skupino</div>
          <input className="field" placeholder="Ime skupine…" value={newName} onChange={(e) => setNewName(e.target.value)} />
          <button className="btn btn-grad" onClick={() => { if (newName.trim()) { toast({ icon: '🎉', text: `Skupina "${newName.trim()}" ustvarjena` }); setNewName(''); } }}>Ustvari</button>
        </div>
        <div className="actioncard">
          <div className="ttl"><span>🔑</span>Pridruži se s kodo</div>
          <input className="field" placeholder="Vnesi kodo…" value={joinCode} onChange={(e) => setJoinCode(e.target.value)} />
          <button className="btn btn-dark" onClick={() => { if (joinCode.trim()) { toast({ icon: '✅', text: 'Pridružen skupini' }); setJoinCode(''); } }}>Pridruži se</button>
        </div>
      </div>

      <div style={{ height: 16 }} />

      {D.myGroups.map((g) => {
        const isOpen = expanded[g.id];
        return (
          <div key={g.id} className="bigcard gcard">
            <div className="gcard-head">
              <div className="gn">{g.name}</div>
              <div className="gtags">
                {g.role === 'Admin' && <span className="tag tag-admin">Admin</span>}
                <span className="tag tag-count">{g.members.length} članov</span>
              </div>
            </div>

            <div className="avstack">
              {g.members.slice(0, 5).map((m, i) => (<div key={i} className="a">{m.emoji}</div>))}
              {g.members.length > 5 && <span className="more">+{g.members.length - 5} več</span>}
            </div>

            <div className="invite">
              <div className="lk">
                <div className="lb">Povabilo link</div>
                <div className="url">/join?code={g.code}</div>
              </div>
              <button className={'copybtn' + (copied === g.id ? ' done' : '')} onClick={() => copy(g)}>
                {copied === g.id ? <React.Fragment><Check /> Kopirano</React.Fragment> : <React.Fragment>📋 Kopiraj</React.Fragment>}
              </button>
            </div>

            <div className="gactions">
              <button className="gactbtn">📊 Lestvica</button>
              <button className={'gactbtn' + (isOpen ? ' on' : '')} onClick={() => setExpanded({ ...expanded, [g.id]: !isOpen })}>
                👥 Člani {isOpen ? '▲' : '▼'}
              </button>
            </div>

            {isOpen && (
              <div className="memberlist">
                {g.members.map((m, i) => (
                  <div key={i} className="memrow">
                    <div className="ma">{m.emoji}</div>
                    <div className="mn">{m.name}</div>
                    {m.you && <div className="mt mt-you">(ti)</div>}
                    {m.admin && <div className="mt mt-admin">Admin</div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}

      <AppFooter />
    </div>
  );
}

// ── PROFIL ────────────────────────────────────────────────────
function Profile({ optIn, setOptIn, onLogout, onAdmin, toast }) {
  const D = window.APPDATA;
  const [confirm, setConfirm] = React.useState(false);

  return (
    <div className="screen">
      <div className="page-title"><h1>Profil</h1></div>

      <div className="bigcard profcard">
        <div className="pa">{D.me.emoji}</div>
        <div>
          <div className="pn">{D.me.name}</div>
          <div className="pe">{D.me.email}</div>
        </div>
      </div>

      <div className="seclabel">Zasebnost</div>
      <div className={'toggle-row' + (optIn ? ' on' : '')} onClick={() => { setOptIn(!optIn); toast(optIn ? { icon: '🔒', text: 'Skrit z globalne lestvice' } : { icon: '🌐', text: 'Viden na globalni lestvici' }); }}>
        <div className="tx">
          <div className="tt"><span>🌐</span>Viden na globalni lestvici</div>
          <div className="td">Tvoje ime in točke so vidni vsem uporabnikom.</div>
        </div>
        <div className="switch"><div className="knob" /></div>
      </div>

      {D.me.isAdmin && (
        <React.Fragment>
          <div className="seclabel">Administracija</div>
          <div className="bigcard" style={{ margin: '0 16px' }} onClick={onAdmin}>
            <div className="memrow" style={{ padding: '14px 16px', cursor: 'pointer' }}>
              <div className="ma" style={{ background: 'var(--teal-light)' }}>🛠️</div>
              <div className="mn">Admin panel</div>
              <svg width="8" height="14" viewBox="0 0 8 14"><path d="M1 1l6 6-6 6" stroke="#cbd2d9" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
          </div>
        </React.Fragment>
      )}

      <div className="seclabel">Račun</div>
      <div style={{ padding: '0 16px' }}>
        <button className="btn btn-ghost" onClick={onLogout}>← Odjava</button>
      </div>

      <div style={{ height: 18 }} />
      <div className="danger">
        <div className="dh"><span>⚠️</span>Nevarno območje</div>
        <div className="dd">Trajno izbriše tvoj račun in vse napovedi. Tega dejanja ni mogoče razveljaviti.</div>
        <button className="btn btn-danger" onClick={() => setConfirm(true)}>Izbriši račun</button>
      </div>

      <AppFooter />

      <div className={'confirm-overlay' + (confirm ? ' show' : '')} onClick={() => setConfirm(false)}>
        <div className="confirm-sheet" onClick={(e) => e.stopPropagation()}>
          <h3>Izbrišem tvoj račun?</h3>
          <p>Vse tvoje napovedi in članstva bodo trajno izbrisani. Tega ni mogoče razveljaviti.</p>
          <div className="row">
            <button className="btn btn-ghost" onClick={() => setConfirm(false)}>Prekliči</button>
            <button className="btn btn-danger-solid" onClick={() => { setConfirm(false); onLogout(); }}>Da, izbriši</button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Dashboard, Leaderboard, Groups, Profile });
