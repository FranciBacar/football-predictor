/* ──────────────────────────────────────────────────────────────
   Football Predictor — shared components
   ────────────────────────────────────────────────────────────── */
const LOGO_URL = 'https://goodish.agency/wp-content/uploads/2023/06/goodish-logotype-full-color-rgb-1024x251.png';

function GoodishLogo({ height = 22 }) {
  // Remote logo is hotlink-blocked from the sandbox; render an on-brand wordmark.
  return (
    <span style={{
      fontFamily: 'Geist, system-ui', fontWeight: 700, color: '#1a1a1a',
      fontSize: height, letterSpacing: '-0.045em', lineHeight: 1,
      display: 'inline-flex', alignItems: 'baseline',
    }}>
      goodish<span style={{ color: '#0f766e' }}>.</span>
    </span>
  );
}

// ── login ──────────────────────────────────────────────────────
function Login({ onLogin }) {
  return (
    <div className="app">
      <div className="statusclear" />
      <div className="scroll">
        <div className="login">
          <div className="login-logo"><GoodishLogo height={28} /></div>

          <div className="login-hero">
            <div className="ball">⚽</div>
            <h1>Football Predictor</h1>
            <div className="sub">Svetovno prvenstvo 2026</div>

            <div className="invite-banner">
              <span>🎉</span>
              <span>Prijaviš se in samodejno se pridružiš skupini <b>Goodish ekipa</b>!</span>
            </div>
          </div>

          <div className="oauth">
            <button className="oauthbtn oa-google" onClick={onLogin}>
              <svg width="19" height="19" viewBox="0 0 18 18"><path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.71-1.57 2.68-3.89 2.68-6.62z"/><path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.8.54-1.84.86-3.04.86-2.34 0-4.32-1.58-5.03-3.7H.96v2.33A9 9 0 0 0 9 18z"/><path fill="#FBBC05" d="M3.97 10.72a5.4 5.4 0 0 1 0-3.44V4.95H.96a9 9 0 0 0 0 8.1l3.01-2.33z"/><path fill="#EA4335" d="M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58A9 9 0 0 0 9 0 9 9 0 0 0 .96 4.95l3.01 2.33C4.68 5.16 6.66 3.58 9 3.58z"/></svg>
              Nadaljuj z Google
            </button>
            <button className="oauthbtn oa-fb" onClick={onLogin}>
              <svg width="19" height="19" viewBox="0 0 24 24" fill="#fff"><path d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07c0 6.02 4.39 11.01 10.13 11.93v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.69 4.53-4.69 1.31 0 2.68.24 2.68.24v2.97h-1.51c-1.49 0-1.96.93-1.96 1.89v2.25h3.33l-.53 3.49h-2.8V24C19.61 23.08 24 18.09 24 12.07z"/></svg>
              Nadaljuj s Facebook
            </button>
            <button className="oauthbtn oa-gh" onClick={onLogin}>
              <svg width="19" height="19" viewBox="0 0 24 24" fill="#fff"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.44 9.8 8.21 11.39.6.11.82-.26.82-.58v-2.03c-3.34.73-4.04-1.61-4.04-1.61-.55-1.39-1.34-1.76-1.34-1.76-1.09-.75.08-.73.08-.73 1.2.09 1.84 1.24 1.84 1.24 1.07 1.83 2.81 1.3 3.5.99.11-.78.42-1.3.76-1.6-2.67-.3-5.47-1.33-5.47-5.93 0-1.31.47-2.38 1.24-3.22-.13-.3-.54-1.52.12-3.18 0 0 1.01-.32 3.3 1.23a11.5 11.5 0 0 1 6 0c2.29-1.55 3.3-1.23 3.3-1.23.66 1.66.25 2.88.12 3.18.77.84 1.24 1.91 1.24 3.22 0 4.61-2.81 5.62-5.49 5.92.43.37.81 1.1.81 2.22v3.29c0 .32.22.7.83.58A12 12 0 0 0 24 12c0-6.63-5.37-12-12-12z"/></svg>
              Nadaljuj z GitHub
            </button>
          </div>

          <div className="login-foot">Narejeno z <span className="heart">❤️</span> v Goodish</div>
        </div>
      </div>
    </div>
  );
}

// ── team display ──────────────────────────────────────────────
function Team({ team }) {
  return (
    <div className="team">
      <div className="flag" style={{ background: hexA(team.color, 0.12) }}>{team.flag}</div>
      <div className="nm">{team.name}</div>
    </div>
  );
}
function hexA(hex, a) {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

// ── score stepper ─────────────────────────────────────────────
function Stepper({ value, onChange, editable, locked }) {
  return (
    <div className={'stepper' + (editable ? ' editable' : '')}>
      <div className={'stepnum' + (locked ? ' locked' : '')}>{value}</div>
      <div className="stepbtns">
        <button className="stepbtn" disabled={!editable || value <= 0} onClick={() => onChange(Math.max(0, value - 1))}>−</button>
        <button className="stepbtn" disabled={!editable || value >= 19} onClick={() => onChange(value + 1)}>+</button>
      </div>
    </div>
  );
}

// ── match card ────────────────────────────────────────────────
function MatchCard({ match, pred, saved, onChange, onSave }) {
  const { status, isKnockout } = match;
  const open = status === 'open';
  const finished = status === 'finished';
  const locked = status === 'locked';

  const p = pred || { home: 0, away: 0 };
  const isDraw = p.home === p.away;
  const dirty = !saved || saved.home !== p.home || saved.away !== p.away || saved.advancing !== p.advancing;
  const needsAdvancing = isKnockout && isDraw;
  const canSave = open && dirty && (!needsAdvancing || p.advancing);

  const statusLabel = open ? 'Odprto' : locked ? 'Zaklenjeno' : 'Končano';
  const sbClass = open ? 'sb-open' : locked ? 'sb-locked' : 'sb-finished';

  // values shown in score area
  const showHome = finished ? match.actual.home : p.home;
  const showAway = finished ? match.actual.away : p.away;

  return (
    <div className="mcard">
      <div className="mcard-top">
        <span className="when">{match.when}</span>
        <span className={'statusbadge ' + sbClass}><span className="led" />{statusLabel}</span>
      </div>
      <div className="mcard-body">
        <div className="matchrow">
          <Team team={match.home} />
          <div className="scorebox">
            <Stepper value={showHome} editable={open} locked={!open}
              onChange={(v) => onChange({ ...p, home: v })} />
            <span className="colon">:</span>
            <Stepper value={showAway} editable={open} locked={!open}
              onChange={(v) => onChange({ ...p, away: v })} />
          </div>
          <Team team={match.away} />
        </div>

        {/* knockout advancing selector */}
        {open && needsAdvancing && (
          <div className="koadv">
            <div className="q"><span>🟢</span><span>Napovedal si remi v izločilnih bojih — kdo napreduje?</span></div>
            <div className="opts">
              {[match.home, match.away].map((t) => (
                <div key={t.code} className={'opt' + (p.advancing === t.code ? ' on' : '')}
                  onClick={() => onChange({ ...p, advancing: t.code })}>
                  <span>{t.flag}</span>{t.name}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* finished result */}
        {finished && (
          <div className="resultstrip">
            <div className="rs-left">
              <span className="lbl">Tvoja napoved</span>
              <span className="val">{match.myPred.home} : {match.myPred.away}</span>
            </div>
            <div className={'ptbadge' + (match.earned === 0 ? ' zero' : '')}>
              {match.earned === 0 ? '0 točk' : `+${match.earned} ${match.earned === 1 ? 'točka' : match.earned === 2 ? 'točki' : 'točke'}`}
            </div>
          </div>
        )}

        {/* save button */}
        {open && (
          <button className={'savebtn' + (!dirty ? ' saved' : '')} disabled={!canSave} onClick={onSave}>
            {!dirty
              ? <React.Fragment><Check /> Napoved shranjena</React.Fragment>
              : needsAdvancing && !p.advancing
                ? 'Izberi, kdo napreduje'
                : 'Shrani napoved'}
          </button>
        )}
        {locked && (
          <button className="savebtn locked" disabled>🔒 Napovedi zaklenjene</button>
        )}
      </div>
    </div>
  );
}

function Check() {
  return <svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M3.5 8.5l3 3 6-7" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

// ── bottom nav ────────────────────────────────────────────────
function BottomNav({ tab, setTab }) {
  const tabs = [
    { id: 'napovedi', label: 'Napovedi', icon: '⚽' },
    { id: 'lestvica', label: 'Lestvica', icon: '📊' },
    { id: 'skupine', label: 'Skupine', icon: '👥' },
    { id: 'profil', label: 'Profil', icon: '👤' },
  ];
  return (
    <div className="bottomnav">
      {tabs.map((t) => (
        <button key={t.id} className={'navtab' + (tab === t.id ? ' on' : '')} onClick={() => setTab(t.id)}>
          <span className="ni">{t.icon}</span>
          <span className="nl">{t.label}</span>
        </button>
      ))}
    </div>
  );
}

// ── app footer ────────────────────────────────────────────────
function AppFooter() {
  return (
    <div className="appfoot">
      <GoodishLogo height={18} />
      <div className="ft">SP 2026 Predictor<br /><a href="https://goodish.agency" target="_blank" rel="noreferrer">goodish.agency →</a></div>
    </div>
  );
}

// ── toast ─────────────────────────────────────────────────────
function Toast({ msg }) {
  return (
    <div className={'toast' + (msg ? ' show' : '')}>
      {msg && msg.icon && <span className="tk">{msg.icon}</span>}
      {msg && msg.text}
    </div>
  );
}

Object.assign(window, { GoodishLogo, Login, Team, Stepper, MatchCard, BottomNav, AppFooter, Toast, Check, hexA, LOGO_URL });
