# Handoff: Football Predictor (Goodish · SP 2026)

> Navodila za Claude Code / razvijalca. Cilj: ta prototip preliti v pravo aplikacijo.
> Aplikacija je v **slovenščini** — vse besedilo v UI naj ostane v slovenščini (glej kopije v `prototype/`).

---

## Overview
Interna mobilna aplikacija za Goodish ekipo in prijatelje za napovedovanje rezultatov tekem na
SP 2026. Uporabnik vnese napoved (rezultat) pred vsako tekmo, sistem po koncu tekme samodejno
izračuna točke in osvežuje lestvico. Zasebne skupine, globalna lestvica, admin panel za vnos/sync
rezultatov.

**Ciljni stack (iz specifikacije):** Next.js 16 (App Router) · Supabase (auth + Postgres) · Tailwind CSS.
**Geste/oblika:** mobile-first (telefon), zgornji navbar na desktopu, spodnji nav na mobile.

---

## About the design files
Datoteke v `prototype/` so **dizajn-reference, narejene v HTML/React (Babel-in-browser)** — kažejo
**videz in obnašanje**, niso produkcijska koda za neposredno kopiranje. Naloga je **poustvariti te
zaslone v ciljnem okolju** (Next.js + Tailwind + Supabase) z njegovimi vzorci in komponentami.
Prototip teče znotraj iPhone okvirja (`ios-frame.jsx`) zgolj za predstavitev — okvir v produkcijo NE gre.

Datoteke:
- `Football Predictor.html` — vstopna točka, naloži fonte + skripte
- `styles.css` — **vir resnice za design tokene** (barve, razmiki, radiji, sence, komponente)
- `data.js` — demo podatki + **scoring engine** (`score()`) + slovenski formatter datuma
- `components.jsx` — Login, MatchCard, Stepper, BottomNav, Toast, GoodishLogo
- `screens.jsx` — Dashboard (Napovedi), Leaderboard (Lestvica), Groups (Skupine), Profile (Profil)
- `admin.jsx` — Admin panel
- `app.jsx` — root state + navigacija + prehodi

## Fidelity
**High-fidelity.** Končne barve, tipografija, razmiki in interakcije so dorečeni. Poustvari UI
pixel-perfect z uporabo Tailwinda. Razmiki/velikosti spodaj so v px (mobile, širina platforme 402px).

---

## Design tokens

Iz `styles.css` (`:root`). Predlagam mapiranje v `tailwind.config` `theme.extend`.

| Token | Vrednost | Uporaba |
|---|---|---|
| `--grad` | `linear-gradient(115deg, #0f766e 0%, #2dd4bf 100%)` | primarni gradient (gumbi, aktivni pilli, avatarji) |
| `--teal` | `#0f766e` | primarna (teal-700) |
| `--teal-600` | `#0d9488` | |
| `--teal-mint` | `#2dd4bf` | konec gradienta |
| `--teal-light` | `#e6faf8` | svetla ozadja, poudarki, izbrane vrstice |
| `--page` | `#f4f6f5` | ozadje strani |
| `--card` | `#ffffff` | kartice |
| `--ink` | `#1a1a1a` | besedilo |
| `--muted` | `#6b7280` | sekundarno besedilo |
| `--line` | `#e6e9e8` | robovi / ločnice |
| `--green` | `#15803d` | status Odprto |
| `--red` | `#dc2626` | status Zaklenjeno / nevarno |
| `--gold` | `#f59e0b` | medalje |

**Tipografija:** Geist (400/500/600/700/800), Geist Mono za kode/linke. `letter-spacing` naslovov −0.02…−0.045em.
Velikosti: naslovi strani 28px/700, pozdrav 25px/700, telo 13–14px, drobni label 11–11.5px, status badge 10.5px.

**Radiji:** kartice 20px, manjše kartice/akcije 16–18px, gumbi 11–14px, stepper-številka 14px, pilli/badge 999px.
**Sence:** kartica `0 1px 2px rgba(16,24,40,.04), 0 8px 24px rgba(16,24,40,.05)`; gradient gumb `0 6px 16px rgba(15,118,110,.28)`.
**Spacing:** stranski rob vsebine 16–20px; razmik med karticami 12px; tap-target ≥ 44px.

---

## Screens / Views

### 1. Login (`/login`) — edina javna stran
- **Layout:** vertikalno centriran; zgoraj Goodish logotip, sredina hero, spodaj OAuth + footer.
- **Komponente:**
  - Goodish logo (klik → goodish.agency). *Opomba: oddaljeni URL je hotlink-blokiran; prototip riše
    besedilni wordmark `goodish.`; v produkciji uporabi pravo SVG/PNG datoteko logotipa.*
  - Teal gradient “žoga” badge (88×88, radius 28) z ⚽, sence teal.
  - Naslov `Football Predictor` (30px/800), podnaslov `Svetovno prvenstvo 2026`.
  - **Invite banner** (pogojno, ko `?inviteCode=XXXX`): zeleno `#ecfdf5`/`#b9e7d4`, besedilo
    “🎉 Prijaviš se in samodejno se pridružiš skupini **<ime>**!”.
  - 3 OAuth gumbi (50px, radius 14): Google (bel + barvni G), Facebook (`#1877F2`), GitHub (`#18181b`).
  - Footer: “Narejeno z ❤️ v Goodish”.
- **Behavior:** klik na OAuth → Supabase OAuth (Google/Facebook/GitHub). Po prijavi: če je `inviteCode`,
  pridruži skupini → `/groups`; sicer → `/dashboard`.

### 2. Dashboard / Napovedi (`/dashboard`) — glavna stran
- **Layout:** pozdravni baner → selektor (skupine + izločilni krogi) → seznam kartic tekem → footer.
- **Pozdrav:** “Pozdravljen, **{ime}**! ⚽” + podnaslov; desno avatar 44px (gradient krog z emoji/sliko).
- **Selektor (pilli):** vodoravno drsljiv (`overflow-x:auto`, brez scrollbara). 12 skupin
  `Skupina A…L` + 5 krogov `Krog 32 · Osmina finala · Četrtfinale · Polfinale · Finale`.
  Aktivni = teal gradient pill + bela pisava; neaktivni = bel pill, rob `--line`.
  *Spec omenja tudi wrap v več vrstic — izbrali smo horizontalni scroll (boljši mobile UX); izbira je odprta.*
- **Kartica tekme (`MatchCard`):**
  - Glava: levo datum (sl format `čet., 11. 06. ob 18:00`), desno **status badge** z LED piko:
    `Odprto` (zelen), `Zaklenjeno` (rdeč), `Končano` (siv).
  - Telo: grid `1fr auto 1fr` → [domača ekipa] [score] [gostujoča]. Ekipa = zastava (46×46 zaobljen
    kvadrat, ozadje = barva ekipe @12% alfa) + ime (12.5px/600).
  - **Score stepper:** velika številka (50×52, teal na `--teal-light`) + gumba −/+ spodaj. Editable le
    pri `Odprto`. Pri `Zaklenjeno`/`Končano` siv, disabled. Meja 0–19.
  - **Odprto:** spodaj gumb “Shrani napoved” (gradient). Ko shranjeno in nespremenjeno → “✓ Napoved
    shranjena” (zeleno, disabled). Klik Shrani → toast “✓ Napoved shranjena”.
  - **Zaklenjeno:** prikaže shranjeno napoved (read-only) + “🔒 Napovedi zaklenjene”.
  - **Končano:** v score prikaže **dejanski rezultat**; spodaj strip “Tvoja napoved X:Y” + **točke badge**
    (`+3 točke` teal, `0 točk` siv).
  - **Izločilni boji — pogojni UX:** če je tekma `isKnockout` in napoved je remi (home===away), se
    pokaže zeleni panel “🟢 Napovedal si remi v izločilnih bojih — kdo napreduje?” z dvema opcijama
    (zastavi + imeni). Dokler napredovalec ni izbran, gumb = “Izberi, kdo napreduje” (disabled).

### 3. Lestvica (`/leaderboard`)
- **Layout:** naslov → pilli (Globalna + ena na skupino) → tabela → info box točkovanja → footer.
- **Tabela:** grid `28px 1fr 44px 50px` = [#] [Igralec] [Točni] [Točke]. Top 3 = 🥇🥈🥉, ostali številka.
  Igralec = avatar 34px (emoji ali iniciala v gradient krogu) + ime; trenutni uporabnik “(ti)” v teal +
  cela vrstica `--teal-light` ozadje, točke v teal.
- **Razvrstitev:** po točkah padajoče; **tie-break: več “točnih rezultatov” (3-točk.)**.
- **Info box (Sistem točkovanja):** 🎯 Točen rezultat — 3 točke · 📐 Pravilna razlika/remi — 2 točki ·
  ✅ Pravilen zmagovalec — 1 točka · ⚡ Bonus (izločilni) — +1 točka.

### 4. Skupine (`/groups`)
- **Layout:** naslov “Moje skupine” → 2-stolpčni grid (Ustvari / Pridruži) → kartice skupin → footer.
- **Ustvari:** vnos “Ime skupine…” + gumb “Ustvari” (gradient). **Pridruži:** vnos “Vnesi kodo…” + gumb
  “Pridruži se” (temno siv `#1f2937`).
- **Kartica skupine:** ime + tagi (`Admin` teal, `{n} članov` siv). Avatar-stack (do 5, prekrivajoči) +
  “+N več”. Invite blok: label “Povabilo link”, `/join?code=XXXX` (Geist Mono), gumb “📋 Kopiraj”
  (klik → clipboard `https://app.goodish.agency/join?code=XXXX`, toast “📋 Povabilo kopirano”, gumb → “✓ Kopirano” 1.6s).
  Spodaj 2 gumba: “📊 Lestvica” in “👥 Člani ▼/▲” (toggle razširi seznam članov: avatar + ime + “(ti)”/“Admin”).

### 5. Profil (`/profile`)
- Profilna kartica: avatar 60px (gradient) + ime (18px/700) + email (muted).
- **Zasebnost toggle:** vrstica “🌐 Viden na globalni lestvici” + opis + iOS-style switch. Vklop = teal rob +
  `--teal-light` ozadje + teal switch. Klik → toast (“🌐 Viden…” / “🔒 Skrit…”). Veže na `users.is_global_opt_in`.
- **Administracija** (le `is_admin`): vrstica “🛠️ Admin panel” → `/admin`.
- **Račun:** gumb “← Odjava” (ghost).
- **Nevarno območje:** rdeča kartica “⚠️ Nevarno območje” + opis + gumb “Izbriši račun” → bottom-sheet
  potrditev “Izbrišem tvoj račun?” z [Prekliči] [Da, izbriši]. Potrditev → izbris + odjava.

### 6. Admin panel (`/admin`) — le `is_admin`
- Header z back gumbom + “🛠️ Admin” chip.
- **Vir podatkov** info kartica: rezultati iz openfootball GitHub repo; cron sync vsakih 30 min (Vercel).
- **Sync:** gumb “Ročni sync zdaj” (gradient) + statistika (Posodobljeno / Preskočeno / Napake).
- **Ročni vnos:** seznam tekem (datum, ekipi, status). Klik razširi inline stepper [0]:[0] +
  [Prekliči]/[Shrani rezultat]. Pri izločilnih z remijem: dodatni izbor “kdo napreduje”.

### 7. Join (`/join?code=XXXX`)
- Brez UI. Če neprijavljen → `/login?inviteCode=XXXX`. Če prijavljen → pridruži skupini → `/groups`.

---

## Interactions & Behavior
- **Navigacija:** spodnji nav (mobile) 4 zavihki: Napovedi ⚽ · Lestvica 📊 · Skupine 👥 · Profil 👤.
  Aktivni = teal (ikona barvna, label gradient-clip); ostali sivi. Desktop: zgornji sticky navbar +
  Goodish logo levo, Profil desno. Footer na vseh straneh: Goodish logo · “SP 2026 Predictor · goodish.agency →”.
- **Prehodi:** ob menjavi zaslona rahel slide-up (~0.3s, `cubic-bezier(.22,1,.36,1)`), spoštuj
  `prefers-reduced-motion`. **Pomembno:** vidnost vsebine NE sme biti odvisna od animacije (animiraj le transform, ne opacity v base stanju).
- **Toast:** pill na dnu (nad navom), avtomatsko skrije ~2.2s.
- **Zaklep napovedi:** 15 min pred začetkom (status → Zaklenjeno, input disabled).
- **Validacija:** rezultat 0–19; pri knockout remiju zahtevaj izbiro napredovalca pred shranjevanjem.

## State / Data
- **Napovedi:** ključ `match_id` → `{ pred_score_home, pred_score_away, pred_advancing_team }`.
  Napoved je **enkratna** (1 na tekmo, velja za vse skupine). “Dirty” stanje = trenutna napoved ≠ shranjena.
- **Točkovanje (engine je v `data.js > score(pred, actual, isKnockout)`):**
  - točen rezultat → **3** · pravilna razlika ali pravilen remi → **2** · pravilen zmagovalec → **1** · sicer **0**
  - knockout bonus: če napovedan remi + dejanski remi + pravilen napredovalec → **+1** (max 4)
  - računaj po **90 minutah**. Trigger ob koncu tekme (async), nato osveži lestvico.
- **Skupinska pravila:** max 50 članov; kreator = admin (lahko odstrani člane); lestvica async.

## Podatkovni model (iz specifikacije)
`users` (id, name, email, avatar_url, is_global_opt_in, is_admin) ·
`matches` (id, home_team, away_team, match_time_utc, stage, is_knockout, status, actual_score_home,
actual_score_away, actual_advancing_team) ·
`predictions` (id, user_id, match_id, pred_score_home, pred_score_away, pred_advancing_team, earned_points) ·
`groups` (id, name, invite_code, creator_user_id) · `group_members` (group_id, user_id, joined_at).

## Assets
- **Goodish logo:** v repu je `prototype/` riše besedilni wordmark `goodish.` (oddaljeni URL je blokiran).
  V produkciji uporabi pravo datoteko logotipa (SVG). Original (referenca):
  `https://goodish.agency/wp-content/uploads/2023/06/goodish-logotype-full-color-rgb-1024x251.png`.
- **Zastave/ikone:** prototip uporablja emoji (zastave + nav ikone). V produkciji razmisli o pravem
  flag-setu (npr. `flag-icons`) za doslednost med platformami.
- **Font:** Geist (Google Fonts / `geist` npm).

## Realni podatki
Prototip vsebuje verjetne skupine SP 2026 (A–L), vključno s 🇸🇮 Slovenijo (skupina K). V produkciji
poveži z openfootball za pravi razpored in rezultate.
